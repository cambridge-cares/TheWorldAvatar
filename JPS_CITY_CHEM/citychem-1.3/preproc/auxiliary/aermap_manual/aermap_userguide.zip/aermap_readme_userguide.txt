 
                      AERMAP User's Guide               04/13/2011
                      
This zipped file contains the User's Guide for the AERMOD Terrain
Preprocessor - AERMAP (EPA-454/B-03-003, October 2004) and the AERMAP
User's Guide Addendum (March 2011).  The current Addendum has
been updated to reflect changes in the AERMAP processor through the 
version dated 11103.

The 2004 AERMAP User's Guide provided with this update to AERMAP 
includes a watermark indicating that the User's Guide is "Under 
Revision - See Addendum."  The current Addendum includes a complete
summary of the current AERMAP options in Appendix B, with detailed 
discussions of any new or updated options.  The 2004 User's Guide
should only be used for a general introduction to the AERMAP input
file structure, or for a more detailed discussion of options that
have not been added or modified since the 2004 User's Guide was
prepared.


